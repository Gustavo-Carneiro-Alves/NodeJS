const msg = "Hello world";
console.log(msg);